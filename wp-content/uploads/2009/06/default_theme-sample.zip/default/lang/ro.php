<?php

global $_LANG;
$_LANG = array();
$_LANG['admin_friends_55ea322d26e4bc5410ef1a4c3754db44'] = 'Editeaza prieten';
$_LANG['admin_friends_3fc6d0c83ae4fa746bcd23c27b5468a3'] = 'Adauga prieten';
$_LANG['admin_friends_c9a8c3e245846326e8d4149a9cb213ac'] = 'Prieteni';
$_LANG['index_b83ee3fac976a626a5fc37144d49c92b'] = 'Ultimile fonduri RSS';
$_LANG['index_c4891ce866e3400a4bff4a18e54c2435'] = 'Ultimile fonduri';
$_LANG['resolutions_5a70003876f3c84d6fce9915b7bbc796'] = 'RSS pentru rezolutia %s';
$_LANG['resolutions_6455c14d24f636de3bc24fee45c752ef'] = 'Rezolutia %s - pagina %s';
$_LANG['8413c683b4b27cc3f4dbd4c90329d8ba'] = 'Comentarii';
$_LANG['4e140ba723a03baa6948340bf90e2ef6'] = 'Nume';
$_LANG['abe854305a8ab993455a8a315d268449'] = 'URL';
$_LANG['6a1e265f92087bb6dd18194833fe946b'] = 'Email';
$_LANG['240f3031f25601fa128bd4e15f0a37de'] = 'Comentariu';
$_LANG['c9cc8cce247e49bae79f15173ce97354'] = 'Salveaza';
$_LANG['526d688f37a86d3c3f27d0c5016eb71d'] = 'Reseteaza';
$_LANG['49ee3087348e8d44e1feda1917443987'] = 'Nume';

?>