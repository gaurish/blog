<?
include_once ("../../config.php");

header("Content-type: text/css; charset: UTF-8");
?>
body
{
	background-image: none;
	filter: progid:DXImageTransform.Microsoft.AlphaImageLoader(src="<?=$template_dir?>images/background1.png", sizingMethod="crop");
}
.top-header
{
	background-image: none;
	filter: progid:DXImageTransform.Microsoft.AlphaImageLoader(src="<?=$template_dir?>images/header-back.png", sizingMethod="crop");
}
.bottom-footer
{
	background-image: none;
	filter: progid:DXImageTransform.Microsoft.AlphaImageLoader(src="<?=$template_dir?>images/footer-back.png", sizingMethod="crop");
}
.container
{
	position:relative;
    background-image: none;
    height:100%;
    background-repeat: no-repeat;
	filter: progid:DXImageTransform.Microsoft.AlphaImageLoader(src="<?=$template_dir?>images/container-back_left1.png", sizingMethod="crop");
}
.container_inside
{
	float:left;
    margin:0;
    padding:20px 20px 20px 20px;
}
.container_right{
	background-image: none;
    background-repeat: no-repeat;
    height:auto;
    min-height:auto;
    position:relative;
    with:970px;
    padding-left:5px;
    overflow:hidden;
}
.container_right_ie
{
	display: block;
    background-image: none;
    width:5px;
    float:left;
    height:100%;
    min-height:100%;
	filter: progid:DXImageTransform.Microsoft.AlphaImageLoader(src="<?=$template_dir?>images/container-back_right1.png", sizingMethod="crop");
}
#ie_background
{
	
	width:980px;
	height:173px;
	position:absolute;
	top:0;
	left:0;
	z-index:1;
	display:block;
}

#header
{
	position:relative;
	z-index:200;
}
.content_background
{
	position:relative;
	z-index:1;
}
ul.wallpapers li.wall{
	margin-right:15px;	
}
.top-menu-ads{
	position:absolute;
	z-index:0;
	float:left;
}
.content_top_ads
{
	height:45px;
}

.rss-image
{
	background-image: none;
	cursor:pointer;
	filter: progid:DXImageTransform.Microsoft.AlphaImageLoader(src="<?=$template_dir?>images/rss.png", sizingMethod="crop");
}
.logo-img
{
	background-image: none;
	cursor:pointer;
	filter: progid:DXImageTransform.Microsoft.AlphaImageLoader(src="<?=$template_dir?>images/logo.png", sizingMethod="crop");
}
.menu
{
	background-image:none;
}
.ratingblock
{
	overflow:hidden;
}

.sIFR-hasFlash h1 {
	font-size: 20px;
	height: 30px;
}
.content
{
	width:606px;
}